/*
Single-file React app (App.jsx)
- Uses two Contexts: AuthContext (name+email) and ThemeContext (dark/light)
- Sign up and Sign in forms (name + email)
- Profile page reads data from AuthContext
- Logout clears auth context
- Theme switch toggles dark / light using ThemeContext (persisted in localStorage)

How to use:
1. Create a new React app (e.g. `npm create vite@latest my-app --template react`) or paste this into an existing React project.
2. Save this file as `App.jsx` and import it into `main.jsx`.
3. Tailwind is used for styling classes. If you don't have Tailwind, the layout still works but styles will be plain — you can replace classes with your own CSS.
*/

import React, { createContext, useContext, useState, useEffect } from 'react'

// -------------------- Auth Context --------------------
const AuthContext = createContext()

function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem('demo-auth')
      return raw ? JSON.parse(raw) : null
    } catch { return null }
  })

  useEffect(() => {
    if (user) localStorage.setItem('demo-auth', JSON.stringify(user))
    else localStorage.removeItem('demo-auth')
  }, [user])

  const signUp = (name, email) => setUser({ name, email })
  const signIn = (name, email) => {
    // naive check: ensure stored user matches
    const raw = localStorage.getItem('demo-auth')
    if (!raw) return false
    const stored = JSON.parse(raw)
    if (stored.email.toLowerCase() === email.toLowerCase() && stored.name.toLowerCase() === name.toLowerCase()){
      setUser(stored)
      return true
    }
    return false
  }
  const logout = () => setUser(null)

  return (
    <AuthContext.Provider value={{ user, signUp, signIn, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

function useAuth(){ return useContext(AuthContext) }

// -------------------- Theme Context --------------------
const ThemeContext = createContext()

function ThemeProvider({ children }){
  const [theme, setTheme] = useState(() => localStorage.getItem('demo-theme') || 'light')
  useEffect(()=>{
    localStorage.setItem('demo-theme', theme)
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])
  const toggle = ()=> setTheme(t=> t === 'dark' ? 'light' : 'dark')
  return (
    <ThemeContext.Provider value={{ theme, toggle }}>
      {children}
    </ThemeContext.Provider>
  )
}
function useTheme(){ return useContext(ThemeContext) }

// -------------------- UI Components --------------------
function AuthCard(){
  const { user } = useAuth()
  return (
    <div className="max-w-md mx-auto p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-lg">
      {user ? <Profile /> : <AuthTabs />}
    </div>
  )
}

function AuthTabs(){
  const [tab, setTab] = useState('signup')
  return (
    <div>
      <div className="flex gap-2 mb-4">
        <button onClick={()=>setTab('signup')} className={`flex-1 py-2 rounded-lg font-semibold ${tab==='signup'? 'bg-blue-500 text-white':'bg-gray-100 dark:bg-gray-700'}`}>Sign Up</button>
        <button onClick={()=>setTab('signin')} className={`flex-1 py-2 rounded-lg font-semibold ${tab==='signin'? 'bg-blue-500 text-white':'bg-gray-100 dark:bg-gray-700'}`}>Sign In</button>
      </div>
      {tab === 'signup' ? <SignUpForm/> : <SignInForm/>}
    </div>
  )
}

function SignUpForm(){
  const { signUp } = useAuth()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [msg, setMsg] = useState('')

  function onSubmit(e){
    e.preventDefault()
    if(!name.trim() || !email.trim()) { setMsg('Provide both name and email'); return }
    if(!/^\S+@\S+\.\S+$/.test(email)) { setMsg('Enter a valid email'); return }
    signUp(name.trim(), email.trim().toLowerCase())
    setMsg('Account created — signed in')
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div>
        <label className="block text-sm font-medium">Full name</label>
        <input value={name} onChange={e=>setName(e.target.value)} className="mt-1 w-full rounded-lg border px-3 py-2 bg-gray-50 dark:bg-gray-900" placeholder="Your full name" />
      </div>
      <div>
        <label className="block text-sm font-medium">Email</label>
        <input value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full rounded-lg border px-3 py-2 bg-gray-50 dark:bg-gray-900" placeholder="you@example.com" />
      </div>
      <div className="flex items-center justify-between">
        <button className="px-4 py-2 rounded-lg bg-blue-500 text-white font-semibold">Create account</button>
      </div>
      {msg && <div className="text-sm text-green-600 dark:text-green-400">{msg}</div>}
    </form>
  )
}

function SignInForm(){
  const { signIn } = useAuth()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [msg, setMsg] = useState('')

  function onSubmit(e){
    e.preventDefault()
    if(!name.trim() || !email.trim()){ setMsg('Provide both name and email'); return }
    const ok = signIn(name.trim(), email.trim().toLowerCase())
    if(!ok) setMsg('No matching user. Try signing up first')
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div>
        <label className="block text-sm font-medium">Full name</label>
        <input value={name} onChange={e=>setName(e.target.value)} className="mt-1 w-full rounded-lg border px-3 py-2 bg-gray-50 dark:bg-gray-900" placeholder="Your full name" />
      </div>
      <div>
        <label className="block text-sm font-medium">Email</label>
        <input value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full rounded-lg border px-3 py-2 bg-gray-50 dark:bg-gray-900" placeholder="you@example.com" />
      </div>
      <div className="flex items-center justify-between">
        <button className="px-4 py-2 rounded-lg bg-blue-500 text-white font-semibold">Sign in</button>
      </div>
      {msg && <div className="text-sm text-rose-600 dark:text-rose-400">{msg}</div>}
    </form>
  )
}

function Profile(){
  const { user, logout } = useAuth()
  const { theme, toggle } = useTheme()
  if(!user) return null
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-sm text-gray-500 dark:text-gray-300">Signed in as</div>
          <div className="mt-1 font-semibold text-lg">{user.name}</div>
          <div className="text-sm text-gray-500">{user.email}</div>
        </div>
        <div className="space-y-2">
          <button onClick={toggle} className="w-full px-3 py-2 rounded-lg border">Theme: {theme}</button>
          <button onClick={logout} className="w-full px-3 py-2 rounded-lg bg-rose-500 text-white">Logout</button>
        </div>
      </div>
      <div className="text-sm text-gray-600 dark:text-gray-300">This is the profile page. Use the logout button to clear the stored data.</div>
    </div>
  )
}

// -------------------- App --------------------
export default function App(){
  return (
    <ThemeProvider>
      <AuthProvider>
        <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900 p-6">
          <div className="w-full max-w-md">
            <div className="mb-6 flex items-center justify-between">
              <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-100">Auth Demo</h1>
              <ThemeToggle />
            </div>
            <AuthCard />
          </div>
        </div>
      </AuthProvider>
    </ThemeProvider>
  )
}

function ThemeToggle(){
  const { theme, toggle } = useTheme()
  return (
    <button onClick={toggle} className="px-3 py-1 rounded-full border">{theme === 'dark' ? '🌙 Dark' : '☀️ Light'}</button>
  )
}
